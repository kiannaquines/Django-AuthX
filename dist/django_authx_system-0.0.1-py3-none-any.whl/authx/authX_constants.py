AUTHX_CONSTANT_CONFIGS = {
    'AUTHX_USER_MODEL' : 'authX.AuthXAppUserModel',
    'AUTHX_LOGIN_URL' : 'login/',
    'AUTHX_REGISTER_URL' : 'register/',
    'AUTHX_LOGOUT_URL' : 'logout/',
    'AUTHX_DASHBOARD_URL' : '/dashboard/',
}
