AUTHX_CONSTANT_CONFIGS = {
    'AUTHX_LOGIN_NAME' : 'login',
    'AUTHX_REGISTER_NAME' : 'register',
    'AUTHX_LOGOUT_NAME' : 'logout',
    'AUTHX_SUCCESS_NAME' : 'dashboard',
    'AUTHX_LOGIN_TEMPLATE': 'login.html',
    'AUTHX_REGISTER_TEMPLATE':'register.html',
}
